#ifndef RECEPTEUR_XBEE_ALL_DATA_H
#define RECEPTEUR_XBEE_ALL_DATA_H

void Affiche(void);
void AfficheVitesse(void);
void AfficheDirection(void);
void AfficheNvPluie(void);
void EtatAffiche(void);
void Bouton(void);
void Son(int son[]);


#endif
