#include "stationmeteo.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    stationMeteo w;
    w.show();

    return a.exec();
}
