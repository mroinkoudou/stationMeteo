#ifndef STATIONMETEO_H
#define STATIONMETEO_H

#include <QMainWindow>

namespace Ui {
class stationMeteo;
}

class stationMeteo : public QMainWindow
{
    Q_OBJECT

public:
    explicit stationMeteo(QWidget *parent = 0);
    ~stationMeteo();



private:
    Ui::stationMeteo *ui;
};

#endif // STATIONMETEO_H
