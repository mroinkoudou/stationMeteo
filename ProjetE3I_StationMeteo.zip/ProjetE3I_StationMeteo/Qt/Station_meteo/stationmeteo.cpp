#include "stationmeteo.h"
#include "ui_stationmeteo.h"

#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <QDebug>

#include <opencv2/opencv.hpp>

using namespace cv;

stationMeteo::stationMeteo(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::stationMeteo)
{
    ui->setupUi(this);
    //namedWindow("b",CV_WINDOW_AUTOSIZE);
    //Mat inputImage = cv::imread("imtest.jpeg");
        //cv::imshow("b", inputImage);

        qDebug() << "Fichier non vide";

    //int i =0;
    //QVector<double> x(28), y(28); // initialize with entries 0..100
    /*for (int i=0; i<28; ++i)
    {
      x[i] = i/50.0 - 1; // x goes from -1 to 1
      y[i] = x[i]*x[i]; // let's plot a quadratic function
    }*/

    connect(ui->pressButton,SIGNAL(clicked(bool)),ui->widget,SLOT(plotPress()));    //plot la pression atmo
    connect(ui->tempButton,SIGNAL(clicked(bool)),ui->widget,SLOT(plotTemp()));    //plot la temperature

}

stationMeteo::~stationMeteo()
{
    delete ui;
}




