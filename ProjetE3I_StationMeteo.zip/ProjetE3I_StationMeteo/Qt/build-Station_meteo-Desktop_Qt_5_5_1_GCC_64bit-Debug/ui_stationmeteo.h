/********************************************************************************
** Form generated from reading UI file 'stationmeteo.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATIONMETEO_H
#define UI_STATIONMETEO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_stationMeteo
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QVBoxLayout *verticalLayout_2;
    QCustomPlot *widget;
    QRadioButton *tempButton;
    QRadioButton *pressButton;
    QWidget *tab_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *stationMeteo)
    {
        if (stationMeteo->objectName().isEmpty())
            stationMeteo->setObjectName(QStringLiteral("stationMeteo"));
        stationMeteo->resize(526, 375);
        centralWidget = new QWidget(stationMeteo);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout_2 = new QVBoxLayout(tab);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        widget = new QCustomPlot(tab);
        widget->setObjectName(QStringLiteral("widget"));

        verticalLayout_2->addWidget(widget);

        tempButton = new QRadioButton(tab);
        tempButton->setObjectName(QStringLiteral("tempButton"));

        verticalLayout_2->addWidget(tempButton);

        pressButton = new QRadioButton(tab);
        pressButton->setObjectName(QStringLiteral("pressButton"));
        pressButton->setChecked(true);

        verticalLayout_2->addWidget(pressButton);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget->addTab(tab_2, QString());

        verticalLayout->addWidget(tabWidget);

        stationMeteo->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(stationMeteo);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 526, 27));
        stationMeteo->setMenuBar(menuBar);
        mainToolBar = new QToolBar(stationMeteo);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        stationMeteo->addToolBar(Qt::TopToolBarArea, mainToolBar);

        retranslateUi(stationMeteo);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(stationMeteo);
    } // setupUi

    void retranslateUi(QMainWindow *stationMeteo)
    {
        stationMeteo->setWindowTitle(QApplication::translate("stationMeteo", "stationMeteo", 0));
        tempButton->setText(QApplication::translate("stationMeteo", "Temp\303\251rature", 0));
        pressButton->setText(QApplication::translate("stationMeteo", "Pression atmosph\303\251rique", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("stationMeteo", "Graphiques", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("stationMeteo", "Donn\303\251es Temps r\303\251el", 0));
    } // retranslateUi

};

namespace Ui {
    class stationMeteo: public Ui_stationMeteo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATIONMETEO_H
